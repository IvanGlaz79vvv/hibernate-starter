create function update_task() returns trigger
    language plpgsql
as
$$
BEGIN

  /* изменили completed с 0 на 1, НЕ изменили категорию */
    IF ( coalesce(old.completed,0)=0 and new.completed=1      and     coalesce(old.category_id,0) = coalesce(new.category_id,0)     ) THEN    
    
		/* у неизмененной категории кол-во незавершенных уменьшится на 1,  кол-во завершенных увеличится на 1 */
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count, 0)-1), completed_count = (coalesce(completed_count,0)+1) where id = old.category_id and user_id=old.user_id; 
        
		 /* общая статистика */
		update todolist.stat set uncompleted_total = (coalesce(uncompleted_total,0)-1), completed_total = (coalesce(completed_total,0)+1)  where user_id=old.user_id;

      
	END IF;
    
    
    /* изменили completed c 1 на 0, НЕ изменили категорию */
    IF (   coalesce(old.completed,1) =1 and new.completed=0       and   coalesce(old.category_id,0) = coalesce(new.category_id,0)   ) THEN    
    
		/* у неизмененной категории кол-во завершенных уменьшится на 1, кол-во незавершенных увеличится на 1 */
		update todolist.category set completed_count = (coalesce(completed_count,0)-1), uncompleted_count = (coalesce(uncompleted_count,0)+1) where id = old.category_id and user_id=old.user_id; 
       
	      /* общая статистика */
		update todolist.stat set completed_total = (coalesce(completed_total,0)-1), uncompleted_total = (coalesce(uncompleted_total,0)+1)  where user_id=old.user_id;

    
	END IF;
    
    
    
	/* изменили категорию, не изменили completed=1 */
    IF ( coalesce(old.category_id,0) <> coalesce(new.category_id,0)      	and      coalesce(old.completed,1) = 1 and new.completed=1   ) THEN    
    
		/* у старой категории кол-во завершенных уменьшится на 1 */
		update todolist.category set completed_count = (coalesce(completed_count,0)-1) where id = old.category_id and user_id=old.user_id; 

        
		/* у новой категории кол-во завершенных увеличится на 1 */
		update todolist.category set completed_count = (coalesce(completed_count,0)+1) where id = new.category_id and user_id=old.user_id; 
	
	
		/* общая статистика не изменяется */
 
	END IF;
    
    
    
    
        
    /* изменили категорию, не изменили completed=0 */
    IF (coalesce(old.category_id,0) <> coalesce(new.category_id,0)     and   coalesce(old.completed,0)= 0  and new.completed=0   ) THEN    
    
		/* у старой категории кол-во незавершенных уменьшится на 1 */
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count,0)-1) where id = old.category_id and user_id=old.user_id; 

		/* у новой категории кол-во незавершенных увеличится на 1 */
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count,0)+1) where id = new.category_id and user_id=old.user_id; 
       
    
	  	/* общая статистика не изменяется */
      
	END IF;
    
    
    
    
    
	
    /* изменили категорию, изменили completed с 1 на 0 */
    IF ( coalesce(old.category_id,0) <> coalesce(new.category_id,0)     and   coalesce(old.completed,1) =1 and new.completed=0   ) THEN    
    
		/* у старой категории кол-во завершенных уменьшится на 1 */
		update todolist.category set completed_count = (coalesce(completed_count,0)-1) where id = old.category_id and user_id=old.user_id; 
        
		/* у новой категории кол-во незавершенных увеличится на 1 */
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count,0)+1) where id = new.category_id and user_id=old.user_id; 

  		/* общая статистика */
		update todolist.stat set uncompleted_total = (coalesce(uncompleted_total,0)+1), completed_total = (coalesce(completed_total,0)-1)  where user_id=old.user_id;
       
	END IF;
    
    
            
    /* изменили категорию, изменили completed с 0 на 1 */
    IF (   coalesce(old.completed,0) =0 and new.completed=1      and   coalesce(old.category_id,0) <> coalesce(new.category_id,0)     ) THEN    
    
		/* у старой категории кол-во незавершенных уменьшится на 1 */
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count,0)-1) where id = old.category_id and user_id=old.user_id; 
        
		/* у новой категории кол-во завершенных увеличится на 1 */
		update todolist.category set completed_count = (coalesce(completed_count,0)+1) where id = new.category_id and user_id=old.user_id; 
        
      /* общая статистика */
		update todolist.stat set uncompleted_total = (coalesce(uncompleted_total,0)-1), completed_total = (coalesce(completed_total,0)+1)  where user_id=old.user_id;
	 	 
	END IF;
    
    
	

	
	RETURN NEW;
	
	END;
$$;

alter function update_task() owner to postgres;

